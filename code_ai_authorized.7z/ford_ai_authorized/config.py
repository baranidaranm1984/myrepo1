# -*- coding: utf-8 -*-
"""
Created on Sat Apr 25 21:21:28 2020

@author: chetankumar.v
"""
token_validator_url = open("config_file.txt", "r").read()
