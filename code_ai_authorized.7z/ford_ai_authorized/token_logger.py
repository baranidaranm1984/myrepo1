# -*- coding: utf-8 -*-
"""
Created on Sat Apr 25 21:44:43 2020

@author: chetankumar.v
"""

import logging

TOKEN_LOGFILE = 'file_name_token.log'
logging.basicConfig(filename=TOKEN_LOGFILE, level=logging.INFO)
token_log = logging.getLogger('token ')
 # create console handler and set level to debug
ch = logging.FileHandler(TOKEN_LOGFILE)
ch.setLevel(logging.INFO)
# create formatter
formatter = logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")
# add formatter to ch
ch.setFormatter(formatter)
# add ch to logger
token_log.addHandler(ch)

