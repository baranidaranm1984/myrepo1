import pandas as pd
import numpy as np
from sklearn.naive_bayes import MultinomialNB
from decoder import decode_supplier, decode_part_base, decode_part_prefix, decode_part_suffix

from flask import Flask,request,jsonify
from flask_cors import CORS, cross_origin
from waitress import serve
from authorizer import authorize

po_data = pd.DataFrame()

def prepare_data(filename = "data/PO_Prefix_Year_new.xlsx"):
    data = pd.read_excel(filename)

    suffix = []
    suffix_data = data[data["part"].notnull()]
    suffix_data = suffix_data[suffix_data["PartPrefix"].notnull()]
    suffix_data = suffix_data[suffix_data["PartBase"].notnull()]
    suffix_data = suffix_data[suffix_data['PartPrefix'] != "."]
    for index, row in suffix_data.iterrows():
        suffix.append(str(row["part"]).replace(str(row['PartPrefix']),'').replace(str(row['PartBase']),''))

    suffix_data["Suffix"] = suffix

    suffix_data = suffix_data[['PartPrefix', 'PartBase', 'Supplier','Suffix']]
    suffix_data = suffix_data[suffix_data['Supplier'].notnull()]
    suffix_data = suffix_data[suffix_data['Suffix'].notnull()]
    suffix_data = suffix_data[suffix_data['PartPrefix'] != "."]

    supplier_shortname = suffix_data["Supplier"].str.split(" ", n=1, expand=True)[0]
    suffix_data["Supplier"] = supplier_shortname

    from encoder import encode_supplier, encode_part_base, encode_part_prefix, encode_part_suffix

    suffix_data['Supplier'] = suffix_data['Supplier'].apply(encode_supplier)
    suffix_data['PartPrefix'] = suffix_data['PartPrefix'].apply(encode_part_prefix)
    suffix_data['PartBase'] = suffix_data['PartBase'].apply(encode_part_base)
    suffix_data['Suffix'] = suffix_data['Suffix'].apply(encode_part_suffix)

    return suffix_data

def get_probablity_from_base(base):
    A = po_data.query('PartBase == {0}'.format(base))["PartBase"].values.reshape(-1, 1)
    b = po_data.query('PartBase == {0}'.format(base))["Supplier"].values

    if len(A) == 0 or len(b) == 0 :
        result = {"top": 0, "count": 0}
        return result

    test = np.array([base]).reshape(-1, 1)
    clf_mNB = MultinomialNB()
    clf_mNB.fit(A, b)
    prob = clf_mNB.predict_proba(test).reshape(-1,1)
    classes = np.array(clf_mNB.classes_).reshape(-1,1)
    result = {}
    top = pd.DataFrame()
    # for supplier, p in zip(classes, prob):
    #     key = str(base) + "_" + str(supplier[0])
    #     if key not in result.keys():
    #         result[str(base) + "_" + str(supplier[0])] = p

    for x in range(len(classes)):
        supplier = classes[x]
        p = prob[x]
        key = str(base) + "_" + str(supplier[0])
        if key not in result.keys():
            result[key] = p[0]

    top["Suppliers"] = classes.reshape(-1,)
    top["Prob"] = prob[0:len(classes)].reshape(-1,)

    top = top.sort_values(by=["Prob"], ascending=False)
    count = A.shape[0]

    top_list = []
    for index, row in top.iterrows():
        top_list.append((decode_supplier(row["Suppliers"]), row["Prob"]))

    del (top)

    result["top"] = top_list
    result["count"] = count

    return result

def get_probablity_from_base_prefix(base, prefix):
    A = po_data.query('PartBase == {0} & PartPrefix == {1}'.format(base, prefix))[
        ["PartBase", "PartPrefix"]].values.reshape(-1, 2)
    b = po_data.query('PartBase == {0}  & PartPrefix == {1}'.format(base, prefix))["Supplier"].values

    if len(A) == 0 or len(b) == 0 :
        result = {"top": 0, "count": 0}
        return result

    test = np.array([base, prefix]).reshape(-1, 2)
    clf_mNB = MultinomialNB()
    clf_mNB.fit(A, b)
    prob = clf_mNB.predict_proba(test).reshape(-1,1)
    classes = np.array(clf_mNB.classes_).reshape(-1,1)
    result = {}
    top = pd.DataFrame()
    for x in range(len(classes)):
        supplier = classes[x]
        p = prob[x]
        key = str(base) + "_" + str(prefix) + "_" + str(supplier[0])
        if key not in result.keys():
            result[key] = p[0]

    # for supplier, p in zip(classes, prob):
    #     key = str(base) + "_" + str(prefix) + "_" + str(supplier)
    #     if key not in result.keys():
    #         result[key] = p

    top["Suppliers"] = classes.reshape(-1,)
    top["Prob"] = prob[0:len(classes)].reshape(-1,)

    top = top.sort_values(by=["Prob"], ascending=False)
    count = A.shape[0]

    top_list = []
    for index, row in top.iterrows():
        top_list.append((decode_supplier(row["Suppliers"]), row["Prob"]))

    del (top)

    result["top"] = top_list
    result["count"] = count

    return result

def get_probablity_from_base_prefix_suffix(base, prefix, suffix):
    A = po_data.query('PartBase == {0} & PartPrefix == {1} & Suffix == {2}'.format(base, prefix, suffix))[
        ["PartBase", "PartPrefix", "Suffix"]].values.reshape(-1, 3)
    b = po_data.query('PartBase == {0}  & PartPrefix == {1} & Suffix == {2}'.format(base, prefix, suffix))[
        "Supplier"].values

    if len(A) == 0 or len(b) == 0 :
        result = {"top": 0, "count": 0}
        return result

    test = np.array([base, prefix, suffix]).reshape(-1, 3)
    clf_mNB = MultinomialNB()
    clf_mNB.fit(A, b)
    prob = clf_mNB.predict_proba(test).reshape(-1,1)
    classes = np.array(clf_mNB.classes_).reshape(-1,1)

    result = {}
    top = pd.DataFrame()
    # for supplier, p in zip(classes, prob):
    #     key = str(base) + "_" + str(prefix) + "_" + str(suffix) + "_" + str(supplier)
    #     if key not in result.keys():
    #         result[key] = p

    for x in range(len(classes)):
        supplier = classes[x]
        p = prob[x]
        key = str(base) + "_" + str(prefix) + "_" + str(suffix) + "_" + str(supplier[0])
        if key not in result.keys():
            result[key] = p[0]

    top["Suppliers"] = classes.reshape(-1,)
    top["Prob"] = prob[0:len(classes)].reshape(-1,)

    top = top.sort_values(by=["Prob"], ascending=False)
    count = A.shape[0]

    top_list = []
    for index, row in top.iterrows():
        top_list.append((decode_supplier(row["Suppliers"]), row["Prob"]))

    del(top)

    result["top"] = top_list
    result["count"] = count

    return result

def process_input_file(file):

    computed_base = {}
    computed_base_prefix = {}
    computed_base_prefix_suffix = {}

    input = pd.read_excel(file)#"data/test1.xlsx"

    suffix = []
    suffix_data = input[input["part"].notnull()]
    suffix_data = suffix_data[suffix_data["PartPrefix"].notnull()]
    suffix_data = suffix_data[suffix_data["PartBase"].notnull()]
    suffix_data = suffix_data[suffix_data['PartPrefix'] != "."]
    for index, row in suffix_data.iterrows():
        suffix.append(str(row["part"]).replace(str(row['PartPrefix']), '').replace(str(row['PartBase']), ''))

    suffix_data["Suffix"] = suffix

    suffix_data = suffix_data[['PartPrefix', 'PartBase', 'Supplier', 'Suffix']]
    suffix_data = suffix_data[suffix_data['Supplier'].notnull()]
    suffix_data = suffix_data[suffix_data['Suffix'].notnull()]

    supplier_shortname = suffix_data["Supplier"].str.split(" ", n=1, expand=True)[0]
    suffix_data["Supplier"] = supplier_shortname

    from encoder import encode_supplier, encode_part_base, encode_part_prefix, encode_part_suffix

    suffix_data['Supplier'] = suffix_data['Supplier'].apply(encode_supplier)
    suffix_data['PartPrefix'] = suffix_data['PartPrefix'].apply(encode_part_prefix)
    suffix_data['PartBase'] = suffix_data['PartBase'].apply(encode_part_base)
    suffix_data['Suffix'] = suffix_data['Suffix'].apply(encode_part_suffix)

    for index, row in suffix_data.iterrows():
        base = row["PartBase"]
        if base not in computed_base.keys():
            result = get_probablity_from_base(base)
            computed_base[str(base)] = result

        prefix = row["PartPrefix"]
        if '{0}_{1}'.format(base, prefix) not in computed_base_prefix.keys():
            result = get_probablity_from_base_prefix (base = base, prefix=prefix)
            computed_base_prefix['{0}_{1}'.format(base, prefix)] = result

        suffix = row["Suffix"]
        if '{0}_{1}_{2}'.format(base, prefix, suffix) not in computed_base_prefix_suffix.keys():
            result = get_probablity_from_base_prefix_suffix (base=base, prefix=prefix, suffix=suffix)
            computed_base_prefix_suffix['{0}_{1}_{2}'.format(base, prefix, suffix)] = result

    json_dict = []
    for index, row in suffix_data.iterrows():
        temp_dict = {}
        # json_dict[index] = {}
        base = str(row["PartBase"])
        prefix = str(row["PartPrefix"])
        suffix = str(row["Suffix"])
        supplier = str(row["Supplier"])

        temp_dict["PartPrefix"] = decode_part_prefix(prefix)
        temp_dict["PartBase"] = decode_part_base(base)
        temp_dict["part"] = decode_part_prefix(prefix)  + decode_part_base(base)  + decode_part_suffix(suffix)
        temp_dict["Supplier"] = decode_supplier(supplier)
        temp_dict["Suffix"] = decode_part_suffix(suffix)

        if base in computed_base.keys() and '{0}_{1}'.format(base, supplier) in computed_base[base].keys():
            temp_dict["pro3"] = computed_base[base]['{0}_{1}'.format(base, supplier)]
        else:
            temp_dict["pro3"] = 0

        if '{0}_{1}'.format(base, prefix) in computed_base_prefix.keys() \
                and '{0}_{1}_{2}'.format(base, prefix, supplier) in computed_base_prefix['{0}_{1}'.format(base, prefix)].keys():
            temp_dict["pro2"] = computed_base_prefix['{0}_{1}'.format(base, prefix)]['{0}_{1}_{2}'.format(base, prefix, supplier)]
        else:
            temp_dict["pro2"] = 0

        if '{0}_{1}_{2}'.format(base, prefix, suffix) in computed_base_prefix_suffix \
                and '{0}_{1}_{2}_{3}'.format(base, prefix, suffix, supplier) in computed_base_prefix_suffix['{0}_{1}_{2}'.format(base, prefix, suffix)].keys():
            temp_dict["pro"] = computed_base_prefix_suffix['{0}_{1}_{2}'.format(base, prefix, suffix)]['{0}_{1}_{2}_{3}'.format(base, prefix, suffix, supplier)]
        else:
            temp_dict["pro"] = 0

        if base in computed_base.keys() and "top" in computed_base[base].keys():
            temp_dict["pro3_values_3"] = str(computed_base[base]["top"]).replace("[", "").replace("]","").replace("),",")").replace(" ", "")
        else:
            temp_dict["pro3_values_3"] = ''

        if '{0}_{1}'.format(base, prefix) in computed_base_prefix.keys() and "top" in computed_base_prefix['{0}_{1}'.format(base, prefix)].keys():
            temp_dict["pro2_values_2"] = str(computed_base_prefix['{0}_{1}'.format(base, prefix)]["top"]).replace("[", "").replace("]","").replace("),",")").replace(" ", "")
        else:
            temp_dict["pro2_values_2"] = ''

        if '{0}_{1}_{2}'.format(base, prefix, suffix) in computed_base_prefix_suffix.keys() and "top" in computed_base_prefix_suffix['{0}_{1}_{2}'.format(base, prefix, suffix)].keys():
            temp_dict["pro_values"] = str(computed_base_prefix_suffix['{0}_{1}_{2}'.format(base, prefix, suffix)]["top"]).replace("[", "").replace("]","").replace("),",")").replace(" ", "")
        else:
            temp_dict["pro_values"] = ''

        json_dict.append(temp_dict)

    import json

    # with open("output.json", "w") as f:
    #     json.dump(json_dict, f)

    # with open("new_json_chetan.json", "r") as f:
    #     test_json = json.load(f)

    return json.dumps(json_dict) #json.dumps(json_dict)


app = Flask(__name__)

app.config['CORS_HEADERS'] = 'Content-Type'
cors = CORS(app, resources={r"/foo": {"origins": "http://127.0.0.1:5000"}})


@app.route('/partbasesite', methods=['GET','POST'])
@cross_origin(origin='localhost',headers=['Content- Type','Authorization'])
def index():
    try:
        api_result = authorize()
        if not authorize():
            data = {'validation': 'false','Reason':'Not authorized'}
            return jsonify(data), 401

        # po_data = prepare_data()
        # df = pd.read_excel()
        input_file = request.files.get('file')
        output = process_input_file(input_file)

        return output
    except Exception as e:
        print(e)
        return e


if __name__ == '__main__':
    import joblib
    # joblib.dump(po_data,"temp.pkl")
    # po_data = joblib.load("temp.pkl")
    po_data = prepare_data()
    print("ready...................")
    serve(app,port=5003)

# try :
#     # po_data = prepare_data()
#     import joblib
#     # joblib.dump(po_data,"temp.pkl")
#     po_data = joblib.load("temp.pkl")
#     output = process_input_file()
#
#     print(output)
# except Exception as e:
#     print(e)







