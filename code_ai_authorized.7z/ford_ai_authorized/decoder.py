import sqlite3

def decode_supplier(id):
    if id == 0:
        return "unknown"

    db = sqlite3.connect("data/gsdb")
    cursor = db.execute("SELECT name from supplier where id = {0} LIMIT 1".format(id))
    value = cursor.fetchone()[0]
    db.close()
    return value

def get_all_suppliers():
    db = sqlite3.connect("data/gsdb")
    cursor = db.execute("SELECT name from supplier")
    suppliers = []
    for row in cursor:
        suppliers.append(row[0])
    db.close()
    return suppliers

def decode_part(id):
    if id == 0:
        return "unknown"

    db = sqlite3.connect("data/gsdb")
    cursor = db.execute("SELECT name from part where id = {0} LIMIT 1".format(id))
    value = cursor.fetchone()[0]
    db.close()
    return value

def decode_part_base(id):
    if id == 0:
        return "unknown"

    db = sqlite3.connect("data/gsdb")
    cursor = db.execute("SELECT name from part_base where id = {0} LIMIT 1".format(id))
    value = cursor.fetchone()[0]
    db.close()
    return value

def decode_part_prefix(id):
    if id == 0:
        return "unknown"

    db = sqlite3.connect("data/gsdb")
    cursor = db.execute("SELECT name from part_prefix where id = {0} LIMIT 1".format(id))
    value = cursor.fetchone()[0]
    db.close()
    return value

def decode_part_suffix(id):
    if id == 0:
        return "unknown"

    db = sqlite3.connect("data/gsdb")
    cursor = db.execute("SELECT name from part_suffix where id = {0} LIMIT 1".format(id))
    value = cursor.fetchone()[0]
    db.close()
    return value


