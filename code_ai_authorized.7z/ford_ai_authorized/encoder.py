import sqlite3

def encode_supplier(name):
    db = sqlite3.connect("data/gsdb")
    cursor = db.execute("SELECT id from supplier where name like '{0}' LIMIT 1".format(name))
    value = cursor.fetchone()
    if value is None:
        # return 0
        db.execute('''INSERT INTO SUPPLIER (NAME) VALUES ('{0}')'''.format(name))
        db.commit()
        cursor = db.execute("SELECT id from supplier where name like '{0}' LIMIT 1".format(name))
        value = cursor.fetchone()

    db.close()
    return value[0]

def encode_part(name):
    db = sqlite3.connect("data/gsdb")
    cursor = db.execute("SELECT id from part where name like '{0}' LIMIT 1".format(name))
    value = cursor.fetchone()
    if value is None:
        return 0

    db.close()
    return value[0]

def encode_part_base(name):
    db = sqlite3.connect("data/gsdb")
    cursor = db.execute("SELECT id from part_base where name like '{0}' LIMIT 1".format(name))
    value = cursor.fetchone()
    if value is None:
        # return 0
        db.execute('''INSERT INTO part_base (NAME) VALUES ('{0}')'''.format(name))
        db.commit()
        cursor = db.execute("SELECT id from part_base where name like '{0}' LIMIT 1".format(name))
        value = cursor.fetchone()

    db.close()
    return value[0]

def encode_part_prefix(name):
    db = sqlite3.connect("data/gsdb")
    cursor = db.execute("SELECT id from part_prefix where name like '{0}' LIMIT 1".format(name))
    value = cursor.fetchone()
    if value is None:
        # return 0
        db.execute('''INSERT INTO part_prefix (NAME) VALUES ('{0}')'''.format(name))
        db.commit()
        cursor = db.execute("SELECT id from part_prefix where name like '{0}' LIMIT 1".format(name))
        value = cursor.fetchone()

    db.close()
    return value[0]

def encode_part_suffix(name):
    db = sqlite3.connect("data/gsdb")
    cursor = db.execute("SELECT id from part_suffix where name like '{0}' LIMIT 1".format(name))
    value = cursor.fetchone()
    if value is None:
        # return 0
        db.execute('''INSERT INTO part_suffix (NAME) VALUES ('{0}')'''.format(name))
        db.commit()
        cursor = db.execute("SELECT id from part_suffix where name like '{0}' LIMIT 1".format(name))
        value = cursor.fetchone()

    db.close()
    return value[0]


