# -*- coding: utf-8 -*-
"""
Created on Sat Apr 25 21:54:59 2020

@author: chetankumar.v
"""
import logging

validator_LOGFILE = 'file_name_validator.log'
logging.basicConfig(filename=validator_LOGFILE, level=logging.INFO)