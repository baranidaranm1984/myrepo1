from flask import request
import requests
import token_logger, validator_logger, config


def authorize():
    token = request.headers.get('Authorization')
    if token is None or len(token) < 5:
        return False

    try:
        token1 = token.split(" ")

        if token1 is None or len(token1) != 2 or token1[1] is None:
            return False

        token2 = token1[1]
        token_logger.token_log.info(token)
        body_data = {}
        body_data['module'] = "AI"
        r = requests.post(config.token_validator_url, json=body_data, headers={'Authorization': token})
        data = r.json()

        valid_log = validator_logger.logging.getLogger('validator ')
        valid_log.info(data)
        res_value = str(data['data'])

        if res_value.lower() == "true":
            return True

        return False
    except Exception as e:
        print(e)
        return False
